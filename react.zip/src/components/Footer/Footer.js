import React from 'react'
import './Footer.css'
const Footer = () => {
  return (
    <div className='footertext'>
      <u className='privacy'>Privacy Policy</u>|© 2022 HighRadius • All rights
      reserved
    </div>
  )
}

export default Footer
